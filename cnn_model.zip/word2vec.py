from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import math
import os
import random
import zipfile

from openpyxl import Workbook,load_workbook
import numpy as np
from six.moves import urllib
from six.moves import xrange  # pylint: disable=redefined-builtin
import tensorflow as tf
import data_helpers

data_index=0
####################################################################################################
####################################################################################################

def read_data(x_text):
    text_data = []
    for sentences in x_text:
        for words in sentences.split():
          text_data.append(words)
    return text_data

# Step 2: Build the dictionary and replace rare words with UNK token.

def build_dataset(words, n_words):
  """Process raw inputs into a dataset."""
  count = [['UNK', -1]]
  count.extend(collections.Counter(words).most_common(n_words - 1))
  vocabulary_size = len(count)
  dictionary = {}  
  for word, _ in count:
    dictionary[word] = len(dictionary)
  data = []    
  unk_count = 0
  for word in words:
    if word in dictionary:
      index = dictionary[word]
    else:
      index = 0 
      unk_count += 1
    data.append(index)
  count[0][1] = unk_count
  reversed_dictionary = dict(zip(dictionary.values(), dictionary.keys()))
  return data, count, dictionary, reversed_dictionary, vocabulary_size

''' 
data = list of text with words replaced with word indexes [8609, 58, 205, 4231, 5976]
count = count of the words in the text [['UNK', -1], ('the', 9029), ('to', 5044), ('of', 4362), ('in', 4046)]
dictionary = python dict of word and their indexes [(b'gangs', 9622), (b'reversed', 6466), (b'O2,', 19255), (b'moment,"', 17000), (b'appointment.', 9618)]
reverse_dictionary = python dict of word indexes and the corresponding words [(0, b'UNK'), (1, b'the'), (2, b'to'), (3, b'of'), (4, b'in')]
'''

'''**********************************************************************************************'''

# Step 3: Function to generate a training batch for the skip-gram model.
def generate_batch(data, batch_size, num_skips, skip_window):
  global data_index
  assert batch_size % num_skips == 0
  assert num_skips <= 2 * skip_window
  batch = np.ndarray(shape=(batch_size), dtype=np.int32)
  labels = np.ndarray(shape=(batch_size, 1), dtype=np.int32)
  span = 2 * skip_window + 1  # [ skip_window target skip_window ]
  buffer = collections.deque(maxlen=span)
  for _ in range(span):
    buffer.append(data[data_index])
    data_index = (data_index + 1) % len(data)
  for i in range(batch_size // num_skips):
    target = skip_window  # target label at the center of the buffer
    targets_to_avoid = [skip_window]
    for j in range(num_skips):
      while target in targets_to_avoid:
        target = random.randint(0, span - 1)
      targets_to_avoid.append(target)
      batch[i * num_skips + j] = buffer[skip_window]
      labels[i * num_skips + j, 0] = buffer[target]
    buffer.append(data[data_index])
    data_index = (data_index + 1) % len(data)
  # Backtrack a little bit to avoid skipping words in the end of a batch
  data_index = (data_index + len(data) - span) % len(data)
  return batch, labels

'''**********************************************************************************************'''

# Step 4: Build and train a skip-gram model.

def create_embeddings(file_present, vocabulary_size, embedding_size, vec_filename, reverse_dictionary):
  embeddings = np.random.uniform(-1,1,(vocabulary_size,embedding_size))
  train_w2v = False
  if file_present:
    word_vec_temp = load_glove(vec_filename, embedding_size)
    print ("\n\nWord Vector file lenght before : ", len(word_vec_temp))
    for key_1,value_1 in reverse_dictionary.items():
      if value_1 in word_vec_temp:
        embeddings = np.delete(embeddings, key_1, axis=0)
        embeddings = np.insert(embeddings, key_1, word_vec_temp[value_1], axis=0)
        break
      else :
        train_w2v = True
  else:
    train_w2v = True
  embeddings = embeddings.astype(np.float32)
  print ('\nEmbeddings shape : ',embeddings.shape)
  print ('\nVocab size : ',vocabulary_size)
  return embeddings, train_w2v


####################################################################################################
####################################################################################################

def build_graph_run_graph(embeddings, embedding_size, vocabulary_size, batch_size, num_skips, skip_window, num_sampled, num_steps, data, reverse_dictionary):
  graph = tf.Graph()
  with graph.as_default():

    # Input data.
    train_inputs = tf.placeholder(tf.int32, shape=[batch_size])
    train_labels = tf.placeholder(tf.int32, shape=[batch_size, 1])

    # Ops and variables pinned to the CPU because of missing GPU implementation
    with tf.device('/cpu:0'):
      # Look up embeddings for inputs.
      embed = tf.nn.embedding_lookup(embeddings, train_inputs,name = 'embeddings')
      # Construct the variables for the NCE loss
      nce_weights = tf.Variable(
          tf.truncated_normal([vocabulary_size, embedding_size],
                              stddev=1.0 / math.sqrt(embedding_size)))
      nce_biases = tf.Variable(tf.zeros([vocabulary_size]))

    # Compute the average NCE loss for the batch.
    # tf.nce_loss automatically draws a new sample of the negative labels each
    # time we evaluate the loss.
    loss = tf.reduce_mean(
        tf.nn.nce_loss(weights=nce_weights,
                       biases=nce_biases,
                       labels=train_labels,
                       inputs=embed,
                       num_sampled=num_sampled,
                       num_classes=vocabulary_size))

    # Construct the SGD optimizer using a learning rate of 1.0.
    optimizer = tf.train.GradientDescentOptimizer(0.75).minimize(loss)

    # Compute the cosine similarity between minibatch examples and all embeddings.
    norm = tf.sqrt(tf.reduce_sum(tf.square(embeddings), 1, keep_dims=True))
    normalized_embeddings = embeddings / norm
    # Add variable initializer.
    init = tf.global_variables_initializer()

  with tf.Session(graph=graph) as session:
    # We must initialize all variables before we use them.
    init.run()
    print('Initialized')

    average_loss = 0
    for step in xrange(num_steps):
      batch_inputs, batch_labels = generate_batch(
          data,batch_size, num_skips, skip_window)
      feed_dict = {train_inputs: batch_inputs, train_labels: batch_labels}

      # We perform one update step by evaluating the optimizer op (including it
      # in the list of returned values for session.run()
      _, loss_val = session.run([optimizer, loss], feed_dict=feed_dict)
      average_loss += loss_val

      if step % 2000 == 0:
        if step > 0:
          average_loss /= 2000
        # The average loss is an estimate of the loss over the last 2000 batches.
        print('Average loss at step ', step, ': ', average_loss)
        average_loss = 0
        
    final_embeddings = normalized_embeddings.eval()
    len_vec = final_embeddings.shape
    # print(len_vec)
    labels = [reverse_dictionary[i] for i in xrange(len_vec[0])]
    # print (len(labels))
    return labels, final_embeddings


####################################################################################################
####################################################################################################


def create_new_vec(labels, final_embeddings, file_present, vec_filename, embedding_size):
  if file_present:
    word_vec_temp = load_glove(vec_filename, embedding_size)
    for i in xrange(len(labels)):
      word_vec_temp[labels[i]] = final_embeddings[i]
  else:
    word_vec_temp = collections.OrderedDict()
    for i in range(len(labels)):
      word_vec_temp[labels[i]] = final_embeddings[i]
  return word_vec_temp

'''**********************************************************************************************'''

def create_vec_file(word_vec_temp, vec_filename):
  print ("\nWord Vector file lenght after : ", len(word_vec_temp))
  with open(vec_filename, 'w', encoding='utf8') as vec_file:
    for key, value in word_vec_temp.items():
      # print ("key : ", key.encoding('utf8'))
      vec_str=''
      for vectors in value:
        vec_str += ' ' + str(vectors)
      word_vec = key+vec_str+'\n'
      vec_file.write(word_vec)

####################################################################################################
####################################################################################################

def load_glove(vec_filename, embedding_size):
    '''
    Loads the GloVe word-vectors with mentioned dimension.
    Return the word vectors in  dictionary format.
    '''
    word_vec = collections.OrderedDict()
    print("==> loading glove")
    with open(vec_filename, encoding = 'utf8') as f:  # "vec" ("glove.6B." + str(dim) + "d.txt" )  ISO-8859-1
        for idx,line in enumerate(f):
            l = line.split()
            for idx,word in enumerate(l):
                if idx !=0:
                    try :
                        float(word)
                        break
                    except :
                        pass
            key = ' '.join(l[:idx])
            if len(list(map(float, l[idx:])))!=embedding_size:
              print (idx, key.encode("utf8"))
            else :
              # print(key)
              word_vec[key] = list(map(float, l[idx:]))
            
    print("==> glove is loaded")
    return word_vec

'''**********************************************************************************************'''

def create_vector(word, dim, word2vec, vec_filename):
    '''
    Creates a word vector if the word is not present in the vocab.
    Returns the updated word vectors.
    '''
    # print ('CREATING VECTOR FOR WORD : ',word)
    vector = np.random.uniform(-1, 1, (dim,))
    word2vec[word] = vector
    with open(vec_filename , 'a') as gw:
      gw.write(str(word))
      for vec in vector.tolist():
        gw.write(' ' + str(vec))
    return word2vec

'''**********************************************************************************************'''

def process_vocab(dim, word_vec):
    '''
    Processes the word vectors from glove.
    Returns vocabulary and the corresponding word-vectors.
    '''
    vocab, word2vec = collections.OrderedDict(), []
    for idx, (word, vec) in enumerate(word_vec.items()):
            vocab[word] = idx
            word2vec.append(list(map(float, vec)))
    print("==> vocab processing is done with vocab, word2vec length : ", len(vocab), len(word2vec))
    return vocab, word2vec

####################################################################################################
####################################################################################################

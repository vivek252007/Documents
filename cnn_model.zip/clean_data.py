from openpyxl import Workbook,load_workbook
import re

def clean_str(string):
    """
    Tokenization/string cleaning for all datasets except for SST.
    Original taken from https://github.com/yoonkim/CNN_sentence/blob/master/process_data.py
    """
    string = string.decode('utf8')
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r'[^\x00-\x7F]+',' ', string)
    string = re.sub(r"'", " ' ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " ( ", string)
    string = re.sub(r"\)", " ) ", string)
    string = re.sub(r"\?", " ? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower().encode('utf8')

def get_data(data_file):
    wb_i, wb_o = load_workbook(data_file), Workbook()
    ws_i, ws_o = wb_i.active, wb_o.active
    for i in range(ws_i.max_row): 
        ws_o.cell(row=i+1,column=1).value = str(ws_i['C'+str(i+1)+''].value)
        ws_o.cell(row=i+1,column=2).value = clean_str(str(ws_i['E'+str(i+1)+''].value).encode('utf8'))
        if str(ws_i['F'+str(i+1)+''].value) != 'None' :
            ws_o.cell(row=i+1,column=3).value = clean_str(str(ws_i['F'+str(i+1)+''].value).encode('utf8'))
        else :
            ws_o.cell(row=i+1,column=3).value = ' '

    file_name = data_file.split('.')[0] + '_cleaned.xlsx'
    wb_o.save(file_name)

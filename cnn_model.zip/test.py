import numpy as np

np_data = np.load('temp_input_data.npz')
input_x_test = np_data['input_x_test'].tolist()
y_test = np_data['y_test']
time_period_news = np_data['date_time_list'].tolist()

print (input_x_test)
print (time_period_news)

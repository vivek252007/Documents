import numpy as np
import data_helpers, word2vec, clean_data

clean_data.get_data("data/AAPL.xlsx")

# np_data = np.load('temp_npz/temp_out_data.npz')['time_period_news'].tolist()
# print (np_data)

# word2vec.load_glove('data/glove.6B.300d.txt',300)

# np_data = np.load('output_data.npz')
# np_data = np.load("temp_input_data.npz")
# time_period = np_data['time_period'].tolist()
# time_period_news = np_data['time_period_news'].tolist()
# y_test = np_data['y_test'].tolist()
# print (y_test)

# print (time_period)
# output_file = "data/blk_stock_data.xlsx"
# a,b = data_helpers.get_time_period(time_period_news, output_file)


# np_data = np.load('output_data.npz')
# time_period = np_data['time_period'].tolist()

# print (time_period)


# np_data = np.load('temp_input_data.npz')
# input_x_test = np_data['input_x_test'].tolist()
# y_test = np_data['y_test']
# time_period_news = np_data['date_time_list'].tolist()

# print (input_x_test[:5])
# print (y_test[:5])
# print (time_period_news)

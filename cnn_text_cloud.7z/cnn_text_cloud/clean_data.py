from openpyxl import Workbook,load_workbook
import re, csv, os
from datetime import datetime
import data_helpers
from collections import Counter, OrderedDict
import numpy as np

def clean_str(string):
    """
    Tokenization/string cleaning for all datasets except for SST.
    Original taken from https://github.com/yoonkim/CNN_sentence/blob/master/process_data.py
    """
    # string = string.decode('utf8')
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r'[^\x00-\x7F]+',' ', string)
    string = re.sub(r"'", " ' ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " ( ", string)
    string = re.sub(r"\)", " ) ", string)
    string = re.sub(r"\?", " ? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()#.encode('utf8')

def get_data(data_file, data_folder):
    wb_i, wb_o = load_workbook(data_file), Workbook()
    ws_i, ws_o = wb_i.active, wb_o.active
    ws_o.cell(row=1,column=1).value = str(ws_i['C'+str(1)+''].value)
    ws_o.cell(row=1,column=2).value = str(ws_i['E'+str(1)+''].value)
    ws_o.cell(row=1,column=3).value = str(ws_i['F'+str(1)+''].value)
    count = 1
    for i in range(ws_i.max_row): 
        date_i = str(ws_i['C'+str(i+2)+''].value).split('.')[0]
        # print (date_i)
        try :
            date_i = datetime.strptime(date_i.rstrip(), '%m/%d/%Y %H:%M')
            ws_o.cell(row=count+1,column=1).value = date_i
        except:
            continue
            
        if str(ws_i['E'+str(i+2)+''].value) != 'None' :
            ws_o.cell(row=count+1,column=2).value = clean_str(str(ws_i['E'+str(i+2)+''].value))
        else :
            ws_o.cell(row=count+1,column=2).value = ' '

        if str(ws_i['F'+str(i+2)+''].value) != 'None' :
            ws_o.cell(row=count+1,column=3).value = clean_str(str(ws_i['F'+str(i+2)+''].value))
        else :
            ws_o.cell(row=count+1,column=3).value = ' '
        count +=1

    file_name = os.path.join(data_folder, "AAPL_cleaned.xlsx")
    wb_o.save(file_name)
    return file_name

def divide_data(ws_i, no_rows, i, file_name, output_filename, impact_time_period, include_text):
    wb_o = Workbook()
    ws_o = wb_o.active
    # head = ws_i.rows[0]
    # ws_o.append(head)
    # data_part = ws_i.rows[i*no_rows:(i+1)*no_rows]
    for r_id, row in enumerate(ws_i.iter_rows(min_row = i*no_rows , max_row = (i+1)*no_rows)):
        for c_id, cell in enumerate(row):
            ws_o.cell(row=r_id+1, column=c_id+1).value = str(cell.value)
    ws_o.cell(row=1, column=1).value = 'Date'
    ws_o.cell(row=1, column=2).value = 'Headline'
    ws_o.cell(row=1, column=3).value = 'Text'
    input_filename = 'temp_data/'+str(i+1)+'.xlsx'
    wb_o.save(input_filename)
    input_x, input_senti, date_time, stock_price = data_helpers.load_data(input_filename, output_filename, impact_time_period, include_text)
    return input_x, input_senti, date_time, stock_price

def multiprocess_data(file_name, output_filename, npz_filename, impact_time_period, include_text):
	import multiprocessing
	from joblib import Parallel, delayed

	num_cores = int(multiprocessing.cpu_count()/2)
	wb_i = load_workbook(file_name, data_only = True)
	ws_i = wb_i.active
	no_rows = int(ws_i.max_row/num_cores)
	# print (ws_i, no_rows, file_name)
	parallel_data = Parallel(n_jobs=num_cores)(delayed(divide_data)(ws_i, no_rows, i, file_name, 
		output_filename, impact_time_period, include_text) for i in range(num_cores))
	# print (parallel_data)
	input_text, input_sentiment, date_time_list, stock_price_list = np.array([]),np.array([]),np.array([]),np.array([])
	for i in parallel_data:
		input_text = np.append(input_text, i[0])
		input_sentiment = np.append(input_sentiment, i[1])
		date_time_list = np.append(date_time_list, i[2])
		stock_price_list = np.append(stock_price_list, i[3])
	print(len(input_text))
	print(len(input_sentiment))
	print(len(date_time_list))
	print(len(stock_price_list))
	input_data = np.column_stack((input_text, input_sentiment, date_time_list, stock_price_list))
	with open('data/input_data.csv', 'w') as f:
		csv.writer(f).writerows(input_data)
	np.savez(npz_filename, input_text=input_text, input_sentiment=input_sentiment, date_time_list=date_time_list, stock_price_list=stock_price_list)

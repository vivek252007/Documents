import word2vec, train, evaluate, plot_sentiment, clean_data, plot_sentiment_binary
import data_helpers as dh
import tensorflow as tf
import word2vec as w2v
import os.path, shutil
import numpy as np
import pandas as pd

####################################################################################################
dirs = ["data", "temp_data", "temp_npz", "temp_npz/word2vec_npz", "temp_npz/train_npz", "temp_npz/eval_npz"]
for directory in dirs:
	if not os.path.exists(directory):
	    os.makedirs(directory)
data_folder = os.path.join(os.getcwd(),'..','aapl_data')
cleaned_data = os.path.join(data_folder, "AAPL_cleaned.xlsx")
####################################################################################################
# DEFINE PARAMETERS
####################################################################################################

# Data loading params
tf.flags.DEFINE_float("dev_sample_percentage", .1, "Percentage of the training data to use for validation (default: 0.1)")
tf.flags.DEFINE_string("vec_filename", "data/glove.6B.300d.txt", "Data source for the word vectors data") 
tf.flags.DEFINE_string("input_filename", os.path.join(data_folder, "AAPL.xlsx"), "Data source for the input headlines data")
tf.flags.DEFINE_string("output_filename", os.path.join(data_folder, "AAPL_stock.xlsx"), "Data source for the sentiment of the headlines")

tf.flags.DEFINE_string("temp_input_data", "temp_npz/clean_input_data.npz", "temporary cleaned input data")
tf.flags.DEFINE_string("temp_test_train_input_data", "temp_npz/train_test_data.npz", "test and train data")

tf.flags.DEFINE_string("temp_word2vec_data", "temp_npz/word2vec_npz/word2vec_embed_data.npz", "temporary input data ready for training")
tf.flags.DEFINE_string("temp_word2vec_embed", "temp_npz/word2vec_npz/word2vec_trained_embed.npz", "temporary input data ready for training")

tf.flags.DEFINE_string("temp_train_data", "temp_npz/train_npz/train_data.npz", "temporary input data ready for training") 
tf.flags.DEFINE_string("train_out_data", 'temp_npz/train_npz/train_out.npz', "temporary input data ready for plotting")

tf.flags.DEFINE_string("temp_test_data", "temp_npz/eval_npz/test_data.npz", "temporary input data ready for testing")
tf.flags.DEFINE_string("temp_out_data", "temp_npz/eval_npz/output_data.npz", "temporary input data ready for plotting")

'''**********************************************************************************************'''

# WordVec Model Hyperparameters
tf.flags.DEFINE_integer("embedding_size", 300, "Dimensionality of character embedding (default: 300)")
tf.flags.DEFINE_integer("num_steps", 100001, "number of steps to train the model")

# WordVec Training Parameters
tf.flags.DEFINE_integer("batch_size_vec", 300,"Size of the batch for training word vectors")
tf.flags.DEFINE_integer("skip_window", 7,"How many words to consider left and right.")
tf.flags.DEFINE_integer("num_skips", 2,"How many times to reuse an input to generate a label.")
tf.flags.DEFINE_integer("num_sampled", 64 ,"Number of negative examples to sample. (default: 64)")

'''**********************************************************************************************'''

# CNN Model Hyperparameters
tf.flags.DEFINE_integer("impact_time_period", 240, "News impact time period on stock prices (default: 4 hours (240 mins))")
tf.flags.DEFINE_string("filter_sizes", "3,4,5", "Comma-separated filter sizes (default: '3,4,5')")
tf.flags.DEFINE_integer("num_filters", 100, "Number of filters per filter size (default: 128)")
tf.flags.DEFINE_float("dropout_keep_prob", 0.5, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("l2_reg_lambda", 3, "L2 regularization lambda (default: 0.0)")

# CNN Training parameters
tf.flags.DEFINE_integer("batch_size", 50, "Batch Size (default: 60)")
tf.flags.DEFINE_integer("num_epochs", 200, "Number of training epochs (default: 200)")
tf.flags.DEFINE_integer("evaluate_every", 100, "Evaluate model on dev set after this many steps (default: 100)")
tf.flags.DEFINE_integer("checkpoint_every", 100, "Save model after this many steps (default: 100)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "Number of checkpoints to store (default: 5)")
tf.flags.DEFINE_boolean("include_text", False, "Include body text data of the article during training")

'''**********************************************************************************************'''

# Evaluation Parameters
tf.flags.DEFINE_integer("accuracy_range", 1, "Range within which the predicted sentiment value should be with actual value to be accurate (default: 0.2)")

'''**********************************************************************************************'''

# Misc Parameters
tf.flags.DEFINE_integer("vocabulary_size", 5000000, "Initial estimated size of the vocabulary")
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")


FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:\n")
for attr, value in sorted(FLAGS.__flags.items()):
    print(("{}={}".format(attr.upper(), value)))
print("")

####################################################################################################
# CLAEN AND GET DATA
'''**********************************************************************************************'''

# if not os.path.isfile(cleaned_data):
# 	clean_data.get_data(FLAGS.input_filename, data_folder)
# clean_data.multiprocess_data(cleaned_data, FLAGS.output_filename, FLAGS.temp_input_data, FLAGS.impact_time_period, FLAGS.include_text)
# dh.get_test_train_data(FLAGS.temp_input_data, FLAGS.temp_test_train_input_data, FLAGS.dev_sample_percentage)
# shutil.rmtree('temp_data/')

####################################################################################################


####################################################################################################
# UPDATE WORD VECTORS
'''**********************************************************************************************'''
'''
input_text = np.load(FLAGS.temp_input_data)['input_text'].tolist()
vocabulary =  word2vec.read_data(input_text)
data, count, dictionary, reverse_dictionary, vocabulary_size = word2vec.build_dataset(vocabulary, FLAGS.vocabulary_size)
del vocabulary, input_text, dictionary, count 

file_present = os.path.isfile(FLAGS.vec_filename )
embeddings, train_w2v = word2vec.create_embeddings(file_present, vocabulary_size, FLAGS.embedding_size, FLAGS.vec_filename, reverse_dictionary)

save_word2vec_file = FLAGS.temp_word2vec_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_word2vec_data
np.savez(save_word2vec_file, embeddings = embeddings, data = np.array(data), reverse_dictionary = np.array([reverse_dictionary]), 
	vocabulary_size = np.array(vocabulary_size), train_w2v= np.array(train_w2v))
del embeddings, train_w2v, reverse_dictionary, data

#####

word2vec_data = np.load(save_word2vec_file)
embeddings = word2vec_data['embeddings']
data = word2vec_data['data']
reverse_dictionary = word2vec_data['reverse_dictionary'][0]
vocabulary_size = int(word2vec_data['vocabulary_size'])
train_w2v = bool(word2vec_data['train_w2v'])

del save_word2vec_file, word2vec_data

if True:
	labels, final_embeddings = word2vec.build_graph_run_graph(embeddings, FLAGS.embedding_size, vocabulary_size, FLAGS.batch_size_vec,
		FLAGS.num_skips, FLAGS.skip_window, FLAGS.num_sampled, FLAGS.num_steps, data, reverse_dictionary)
	np.savez(FLAGS.temp_word2vec_embed, labels= np.array(labels), final_embeddings= np.array(final_embeddings))
	word_vec_temp = word2vec.create_new_vec(labels, final_embeddings, file_present, FLAGS.vec_filename, FLAGS.embedding_size)
	word2vec.create_vec_file(word_vec_temp, FLAGS.vec_filename)
	del word_vec_temp, labels, final_embeddings
del embeddings, data, reverse_dictionary, vocabulary_size
'''
####################################################################################################


####################################################################################################
# TRAIN THE MODEL

word_vec_temp = w2v.load_glove(FLAGS.vec_filename, FLAGS.embedding_size)
x_train = np.load(FLAGS.temp_test_train_input_data)['x_train'].tolist()
y_train = np.load(FLAGS.temp_test_train_input_data)['y_train']

x_train, x_dev, y_train, y_dev, word2vec, max_length_vec = dh.load_test_train_data(x_train, y_train,
	FLAGS.include_text, FLAGS.embedding_size, word_vec_temp, FLAGS.vec_filename, FLAGS.dev_sample_percentage, FLAGS.impact_time_period, False)
print(x_train.shape, y_train.shape)
del word_vec_temp

save_train_file = FLAGS.temp_train_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_train_data
np.savez(save_train_file, x_train = x_train, x_dev = x_dev, y_train = y_train, y_dev = y_dev, 
	word2vec = word2vec, max_length_vec = np.array(max_length_vec))
del x_train, x_dev, y_train, y_dev, word2vec, max_length_vec

####

save_train_file = FLAGS.temp_train_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_train_data
train_data = np.load(save_train_file)
x_train = train_data['x_train']
x_dev = train_data['x_dev']
y_train = train_data['y_train']
y_dev = train_data['y_dev']
word2vec = train_data['word2vec']
max_length_vec = int(train_data['max_length_vec'])

del save_train_file, train_data

out_dir = train.train_model(x_train, x_dev, y_train, y_dev, word2vec, FLAGS.allow_soft_placement, FLAGS.log_device_placement,
	FLAGS.embedding_size, FLAGS.filter_sizes, FLAGS.num_filters, FLAGS.l2_reg_lambda, FLAGS.num_checkpoints,
	FLAGS.dropout_keep_prob, FLAGS.batch_size, FLAGS.num_epochs, FLAGS.evaluate_every, FLAGS.checkpoint_every)

out_dir =  'runs/'+str(out_dir).split("runs")[-1][1:]+'/checkpoints/'
print ('THE MODEL DIRECTORY IS : ', out_dir)
print ('MAX LENGTH VECTOR : ', max_length_vec)
np.savez(FLAGS.train_out_data, out_dir=out_dir, max_length_vec=max_length_vec)
del x_train, y_train, x_dev, y_dev, word2vec, max_length_vec

####################################################################################################


####################################################################################################
# EVALUATE THE MODEL AND PRINT RESULTS
'''**********************************************************************************************'''
word_vec_temp = w2v.load_glove(FLAGS.vec_filename, FLAGS.embedding_size)
# out_dir = "runs/1494941045/checkpoints/"
# max_length_vec = 422 
print (out_dir)
x_test = np.load(FLAGS.temp_test_train_input_data)['x_dev'].tolist()
y_test = np.load(FLAGS.temp_test_train_input_data)['y_dev'].tolist()
out_dir = str(np.load(FLAGS.train_out_data)["out_dir"])
max_length_vec = int(np.load(FLAGS.train_out_data)['max_length_vec'])

x_test, y_test, x_raw = dh.load_test_train_data(x_test, y_test,
	FLAGS.include_text, FLAGS.embedding_size, word_vec_temp, FLAGS.vec_filename, FLAGS.dev_sample_percentage, FLAGS.impact_time_period, max_length_vec)

del word_vec_temp

save_test_file = FLAGS.temp_test_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_test_data
np.savez(save_test_file, x_test = x_test, y_test = y_test, out_dir = np.array(out_dir))

# '''**********************************************************************************************'''
save_test_file = FLAGS.temp_test_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_test_data
test_data = np.load(save_test_file)
x_test = test_data['x_test']
y_test = test_data['y_test']
x_raw = np.load(FLAGS.temp_test_train_input_data)['x_dev'].tolist()
#out_dir = str(test_data['out_dir'])
out_dir = "runs/1495914605/checkpoints/"
time_period_news = np.load(FLAGS.temp_test_train_input_data)['date_time_dev']
max_length_vec = int(np.load(FLAGS.train_out_data)['max_length_vec'])
x_temp_test, y_temp_test, x_test_raw, time_period_news_test = [],[],[],[]
for i in range(len(x_test)):
    if len(x_test[i]) == max_length_vec:
        x_temp_test.append(x_test[i])
        y_temp_test.append(y_test[i])
        x_test_raw.append(x_raw[i])
        time_period_news_test.append(time_period_news[i])
    print ('Shape of element : ', len(x_test[i]))
x_test = np.array(x_temp_test)
y_test = np.array(y_temp_test)
x_raw = x_test_raw
time_period_news = time_period_news_test
print('Out dir : ', x_test.shape)

del save_test_file, test_data

percent_accuracy, sentiments, sentiments_binary, corr = evaluate.model_evaluation(x_test, y_test, out_dir,
	FLAGS.allow_soft_placement, FLAGS.log_device_placement, FLAGS.batch_size, x_raw, FLAGS.accuracy_range, time_period_news)

del x_test, y_test, out_dir
'''
time_period, stock_prices = dh.get_time_period(time_period_news, FLAGS.output_filename)

save_out_file = FLAGS.temp_out_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_out_data
np.savez(save_out_file, time_period = np.array(time_period), time_period_news = np.array(time_period_news), 
	stock_prices = np.array(stock_prices), sentiments = np.array(sentiments), sentiments_binary = np.array(sentiments_binary),
	percent_accuracy = np.array(percent_accuracy), corr = np.array(corr), x_raw = np.array(x_raw))
'''
# '''**********************************************************************************************'''

# np_data_out = np.load(save_out_file)
# time_period = np_data_out['time_period'].tolist()
# time_period_news = np_data_out['time_period_news'].tolist()
# stock_prices = np_data_out['stock_prices'].tolist()
# sentiments = np_data_out['sentiments'].tolist()
# sentiments_binary = np_data_out['sentiments_binary'].tolist()
# percent_accuracy = float(np_data_out['percent_accuracy'])
# corr = float(np_data_out['corr'])
# x_raw = np_data_out['x_raw'].tolist()

# del save_out_file, np_data_out

# plot_sentiment.plot_sentiment(time_period = time_period, time_period_news = time_period_news, stock_prices = stock_prices, 
# 	sentiment_values = sentiments, news_headlines = x_raw, corr_value =  corr*100)

# plot_sentiment_binary.plot_sentiment(time_period = time_period, time_period_news = time_period_news, stock_prices = stock_prices, 
# 	sentiment_values = sentiments_binary, news_headlines = x_raw, percent_accuracy =  percent_accuracy*100)

####################################################################################################

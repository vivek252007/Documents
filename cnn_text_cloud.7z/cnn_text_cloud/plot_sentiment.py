from plotly import tools
from plotly.offline import plot as py
import plotly.graph_objs as go

def pos_neg(time_period, time_period_news, stock_prices, sentiment_values, news_headlines):
	# print('\nTIME PERIOD NEWS : ',time_period_news)
	# print('\nTIME PERIOD : ',time_period)
	time_period_pos, sentiment_values_pos, news_headlines_pos, time_period_neg, sentiment_values_neg, news_headlines_neg = [],[],[],[],[],[]
	time_periods, time_periods_news = [],[]
	count = 0
	for idx in range(len(time_period)):
		# print ('Time period iteration : ', idx)
		time_periods.append(idx)
		if time_period[idx] in time_period_news:
			# print ('Count of time period : ',time_period_news.count(time_period[idx]))
			for i in range(time_period_news.count(time_period[idx])):
				# print('TIME PERIOD NEWS SELECTED : ', time_period[idx], ' with SENTIMENT VALUE : ',sentiment_values[count] )
				# print ('Count is : ', count)
				if sentiment_values[count]>=0:
					time_period_pos.append(idx)
					sentiment_values_pos.append(sentiment_values[count])
					news_headlines_pos.append(news_headlines[count])
				if sentiment_values[count]<0:
					time_period_neg.append(idx)
					sentiment_values_neg.append(sentiment_values[count])
					news_headlines_neg.append(news_headlines[count])
				count +=1
	print ('Final Count : ',count)
	return time_periods, time_periods_news, time_period_pos, sentiment_values_pos, news_headlines_pos, time_period_neg, sentiment_values_neg, news_headlines_neg


def plot_sentiment(
	time_period = ['2017-04-02 13:42:00','2017-04-02 14:30:00','2017-04-02 15:07:02'],
	time_period_news = ['2017-04-02 13:42:00','2017-04-02 14:30:00','2017-04-02 15:07:02'],
	stock_prices = [50, 60, 70],
	sentiment_values = [1.2, 0,-1],
	news_headlines = ['The system is not.', '', 'in this company.'], 
	corr_value = 80 ):

	time_periods, time_periods_news, time_period_pos, sentiment_values_pos, news_headlines_pos, time_period_neg, sentiment_values_neg, news_headlines_neg = pos_neg(time_period, time_period_news, stock_prices, sentiment_values, news_headlines)
	
	stock_sentiment_pos = go.Bar(
	    x=time_period_pos,
	    y=sentiment_values_pos,
	    name = 'Positive Sentiment',
	    text = news_headlines_pos,
	    marker=dict(color="rgb(13, 155, 58)")
	)
	stock_sentiment_neg = go.Bar(
	    x=time_period_neg,
	    y=sentiment_values_neg,
	    name = 'Negative Sentiment',
	    text = news_headlines_neg,
	    marker=dict(color="rgb(150, 16, 18)")
	)
	stock_price = go.Scatter(
	    x=time_periods,
	    y=stock_prices,
	    name = 'Stock Price',
	    marker = dict(color="rgb(16, 82, 188)")
	)

	#layout = go.Layout(yaxis=dict(range=[-1,1]))

	fig = tools.make_subplots(rows=2, cols=1, subplot_titles=("Sentiment Value","Stock Price"), shared_xaxes=True)

	fig.append_trace(stock_sentiment_pos, 1, 1)
	fig.append_trace(stock_sentiment_neg, 1, 1)
	fig.append_trace(stock_price, 2, 1)

	# fig['layout'].update(height=600, width=600, title='News Sentiment')
	fig['layout'].update(title=" NEWS SENTIMENT INDICATOR ( Correlation : "+str(corr_value)+"%)")
	py(fig, filename='sentiment_output.html')

# plot_sentiment(percent_accuracy = 95)
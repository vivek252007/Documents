#! /usr/bin/env python

import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers
from text_cnn import TextCNN
import word2vec as w2v
from tensorflow.contrib import learn
import csv


def load_eval_data(input_filename, output_filename, include_text, embedding_dim, word_vec, vec_filename, max_length_vec):
    print("Loading data...")
    if True:
        x_raw, y_test, date_time_list, stock_prices = data_helpers.get_data(input_filename.split('.')[0] + '_test.xlsx', output_filename, include_text)
        #x_raw, y_test = data_helpers.load_data_and_labels(FLAGS.positive_data_file, FLAGS.negative_data_file)
        y_test = np.argmax(y_test, axis=1)
    else:
        x_raw = ["good", "everything is off ."]
        y_test = [1, 0]
    vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec)
    x, max_doc_len = [],0
    for sentences in x_raw:
        temp =[]
        for words in sentences.split():
            try:
                temp.append(vocab[words])
            except KeyError as e:
                print('Adding missing word to the vocabulary==> %s' % str(e))
                word2vec = w2v.create_vector(words, embedding_dim, word_vec, vec_filename)
                vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec)
                temp.append(vocab[words])
        x.append(temp)
    # length = len(sorted(x,key=len, reverse=True)[0])
    x_data = np.array([xi+[0]*(max_length_vec-len(xi)) for xi in x])
    # Map data into vocabulary
    print('\n\nINPUT DATA : ', x_data.shape)
    print ('\n\nOUTPUT DATA : ', y_test)
    print("\nEvaluating...\n")
    return x_data, y_test, x_raw, date_time_list, stock_prices

# Evaluation
# ==================================================
def model_evaluation(x_data, y_test, checkpoint_dir, allow_soft_placement, log_device_placement, batch_size, x_raw):
    checkpoint_file = tf.train.latest_checkpoint(checkpoint_dir)
    print ('CHECKPOINT FILE : ', checkpoint_file)
    graph = tf.Graph()
    with graph.as_default():
        session_conf = tf.ConfigProto(
          allow_soft_placement=allow_soft_placement,
          log_device_placement=log_device_placement)
        sess = tf.Session(config=session_conf)
        with sess.as_default():
            # Load the saved meta graph and restore variables
            saver = tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
            saver.restore(sess, checkpoint_file)

            # Get the placeholders from the graph by name
            input_x = graph.get_operation_by_name("input_x").outputs[0]
            # input_y = graph.get_operation_by_name("input_y").outputs[0]
            dropout_keep_prob = graph.get_operation_by_name("dropout_keep_prob").outputs[0]

            # Tensors we want to evaluate
            predictions = graph.get_operation_by_name("output/predictions").outputs[0]

            # Generate batches for one epoch
            batches = data_helpers.batch_iter(list(x_data), batch_size, 1, shuffle=False)
            print (batches)

            # Collect the predictions here
            all_predictions = []

            for x_test_batch in batches:
                batch_predictions = sess.run(predictions, {input_x: x_test_batch, dropout_keep_prob: 1.0})
                all_predictions = np.concatenate([all_predictions, batch_predictions])

    # Print accuracy if y_test is defined
    if y_test is not None:
        print(all_predictions)
        correct_predictions = float(sum(all_predictions == y_test))
        print(("Total number of test examples: {}".format(len(y_test))))
        accuracy = correct_predictions/float(len(y_test))
        print(("Accuracy: {:g}".format(accuracy)))

    # Save the evaluation to a csv
    predictions_human_readable = np.column_stack((np.array(x_raw), all_predictions,y_test))
    out_path = os.path.join(checkpoint_dir, "..", "prediction.csv")
    print(("Saving evaluation to {0}".format(out_path)))
    with open(out_path, 'w') as f:
        csv.writer(f).writerows(predictions_human_readable)
    return accuracy, all_predictions
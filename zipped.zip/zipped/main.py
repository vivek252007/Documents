import word2vec,train
import data_helpers as dh
import tensorflow as tf

# Data loading params
tf.flags.DEFINE_float("dev_sample_percentage", .1, "Percentage of the training data to use for validation")
tf.flags.DEFINE_string("vec_filename", "data/vectors.txt", "Data source for the word vectors data")  #"glove.6B." + str(embedding_size) + "d.txt" 
tf.flags.DEFINE_string("input_filename", "data/AAPL.xlsx", "Data source for the input headlines data")
tf.flags.DEFINE_string("output_filename", "data/Stock_Price.xlsx", "Data source for the sentiment of the headlines")

# WordVec Model Hyperparameters
tf.flags.DEFINE_integer("embedding_size", 300, "Dimensionality of character embedding (default: 300)")
tf.flags.DEFINE_integer("num_steps", 100001, "number of steps to train the model")

# WordVec Training Parameters
tf.flags.DEFINE_integer("batch_size_vec", 300,"Size of the batch for training word vectors")
tf.flags.DEFINE_integer("skip_window", 7,"How many words to consider left and right.")
tf.flags.DEFINE_integer("num_skips", 2,"How many times to reuse an input to generate a label.")
tf.flags.DEFINE_integer("num_sampled", 64,"Number of negative examples to sample.")

# CNN Model Hyperparameters
tf.flags.DEFINE_string("filter_sizes", "3,4,5", "Comma-separated filter sizes (default: '3,4,5')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 128)")
tf.flags.DEFINE_float("dropout_keep_prob", 0.5, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("l2_reg_lambda", 0.0, "L2 regularization lambda (default: 0.0)")

# CNN Training parameters
tf.flags.DEFINE_integer("batch_size", 10, "Batch Size (default: 10)")
tf.flags.DEFINE_integer("num_epochs", 20, "Number of training epochs (default: 20)")
tf.flags.DEFINE_integer("evaluate_every", 20, "Evaluate model on dev set after this many steps (default: 20)")
tf.flags.DEFINE_integer("checkpoint_every", 20, "Save model after this many steps (default: 20)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "Number of checkpoints to store (default: 5)")
tf.flags.DEFINE_boolean("include_text", False, "Include body text data of the article during training")

# Evaluation Parameters
tf.flags.DEFINE_string("checkpoint_dir", "runs/headline_model/checkpoints/", "Checkpoint directory from training run")
tf.flags.DEFINE_boolean("eval_train", True, "Evaluate on all training data")

# Misc Parameters
tf.flags.DEFINE_integer("vocabulary_size", 5000000, "Initial estimated size of the vocabulary")
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")


FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:\n")
for attr, value in sorted(FLAGS.__flags.items()):
    print(("{}={}".format(attr.upper(), value)))
print("")

# UPDATE WORD VECTORS
####################################################################################################

vocabulary =  word2vec.read_data(FLAGS.input_filename)
data, count, dictionary, reverse_dictionary,vocabulary_size = word2vec.build_dataset(vocabulary,FLAGS.vocabulary_size)
del vocabulary 

word_vec_temp = dh.load_glove(FLAGS.embedding_size)
embeddings,file_present = word2vec.create_embeddings(word_vec_temp,vocabulary_size,FLAGS.embedding_size,FLAGS.vec_filename,reverse_dictionary)

labels,final_embeddings = word2vec.build_graph_run_graph(embeddings,FLAGS.embedding_size,vocabulary_size,FLAGS.batch_size_vec,FLAGS.num_skips,FLAGS.skip_window,FLAGS.num_sampled,FLAGS.num_steps,data,reverse_dictionary)

word_vec_temp = word2vec.create_new_vec(labels, final_embeddings,file_present,FLAGS.vec_filename,word_vec_temp)
word2vec.create_vec_file(word_vec_temp,FLAGS.vec_filename)
####################################################################################################


# TRAIN THE MODEL
####################################################################################################

x_train,x_dev,y_train,y_dev,word2vec,max_length_vec = train.load_data(FLAGS.input_data_file,FLAGS.output_data_file,FLAGS.include_text,FLAGS.embedding_size,word_vec_temp)

out_dir = train.train_model(x_train,x_dev,y_train,y_dev,word2vec,FLAGS.allow_soft_placement,FLAGS.log_device_placement,FLAGS.embedding_size,FLAGS.filter_sizes,
	FLAGS.num_filters,FLAGS.l2_reg_lambda,FLAGS.num_checkpoints,FLAGS.dropout_keep_prob, FLAGS.batch_size, FLAGS.num_epochs,FLAGS.evaluate_every,FLAGS.checkpoint_every)

####################################################################################################



# EVALUATE THE MODEL AND PRINT RESULTS
####################################################################################################

model_evaluation(x_data,FLAGS.checkpoint_dir,FLAGS.allow_soft_placement,FLAGS.log_device_placement,FLAGS.batch_size)
plot_sentiment(time_period,	stock_price, sentiment_index, news_headlines, percent_accuracy)

####################################################################################################

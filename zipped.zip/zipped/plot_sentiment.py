from plotly import tools
from plotly.offline import plot as py
import plotly.graph_objs as go

def plot_sentiment(
	time_period = ['2017-04-02 13:42:00','2017-04-02 14:30:00','2017-04-02 15:07:02'],
	stock_price = [50, 60, 70],
	sentiment_index = [1, -1, 1],
	news_headlines = ['The system is not.', "working at all", 'in this company.'], 
	percent_accuracy = 80 ):

	stock_sentiment = go.Bar(
	    x=time_period,
	    y=sentiment_index,
	    name = 'Stock Sentiment',
	    text = news_headlines,
	)
	stock_price = go.Scatter(
	    x=time_period,
	    y=stock_price,
	    name = 'Stock Price'
	)

	#layout = go.Layout(yaxis=dict(range=[-1,1]))

	fig = tools.make_subplots(rows=2, cols=1,subplot_titles=("Sentiment Value","Stock Price"), shared_xaxes=True)

	fig.append_trace(stock_sentiment, 1, 1)
	fig.append_trace(stock_price, 2, 1)

	# fig['layout'].update(height=600, width=600, title='News Sentiment')
	fig['layout'].update(title=" NEWS SENTIMENT INDICATOR ( ACCURACY : "+str(percent_accuracy)+"% )")
	py(fig, filename='sentiment_output.html')

# plot_sentiment(percent_accuracy = 95)
#! /usr/bin/env python

import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers
from text_cnn import TextCNN
from tensorflow.contrib import learn
import csv


# Evaluation
# ==================================================
def model_evaluation(x_data, y_test, checkpoint_dir, allow_soft_placement, log_device_placement, batch_size, x_raw, accuracy_range, time_period):
    checkpoint_file = tf.train.latest_checkpoint(checkpoint_dir)
    print ('CHECKPOINT FILE : ', checkpoint_file)
    # checkpoint_file = 'runs/1494941045/checkpoints/model-2600'
    graph = tf.Graph()
    with graph.as_default():
        session_conf = tf.ConfigProto(
          allow_soft_placement=allow_soft_placement,
          log_device_placement=log_device_placement)
        sess = tf.Session(config=session_conf)
        with sess.as_default():
            # Load the saved meta graph and restore variables
            saver = tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
            saver.restore(sess, checkpoint_file)

            # Get the placeholders from the graph by name
            input_x = graph.get_operation_by_name("input_x").outputs[0]
            # input_y = graph.get_operation_by_name("input_y").outputs[0]
            dropout_keep_prob = graph.get_operation_by_name("dropout_keep_prob").outputs[0]

            # Tensors we want to evaluate
            # predictions = graph.get_operation_by_name("output/predictions").outputs[0]
            scores = graph.get_operation_by_name("output/scores").outputs[0]

            # Generate batches for one epoch
            batches = data_helpers.batch_iter(list(x_data), batch_size, 1, shuffle=False)
            # print ('BATCHES Length : ',batches)

            # Collect the predictions here
            all_predictions = []

            for x_test_batch in batches:
                batch_predictions = sess.run(scores, {input_x: x_test_batch, dropout_keep_prob: 1.0})
                print ('SCores : ', batch_predictions)
                for senti_score in batch_predictions.tolist():
                    all_predictions.append(senti_score[0])
            # print ('ALL Predictions : ', all_predictions)
    
    # Print accuracy if y_test is defined
    if y_test is not None:
        y_test = y_test
        # print ('BEFORE : ',y_test)
        y_test = [val for idx in y_test for val in idx]
        # print ('AFTER : ',y_test)
        count, all_predictions_binary = 0, [] 
        for idx in range(len(y_test)):
            if all_predictions[idx]>0:
                all_predictions_binary.append(1)
                # print ('Positive Condition : ',max(0,float(y_test[idx])- accuracy_range*float(y_test[idx])), float(all_predictions[idx]), min(1, float(y_test[idx]) + accuracy_range*float(y_test[idx])))
                # (max(0,float(y_test[idx])- accuracy_range*1)<= float(all_predictions[idx]) <= min(1, float(y_test[idx]) + accuracy_range*1))
                if y_test[idx] > 0:
                    count+=1
            if all_predictions[idx]<0:
                all_predictions_binary.append(-1)
                # print ('Negative Condition : ',max(-1, float(y_test[idx])+ accuracy_range*float(y_test[idx])), float(all_predictions[idx]), min(0, float(y_test[idx])- accuracy_range*float(y_test[idx])))
                # (max(-1, float(y_test[idx])+ accuracy_range*(-1))<= float(all_predictions[idx]) <= min(0, float(y_test[idx])- accuracy_range*(-1)))
                if y_test[idx] < 0:
                    count+=1
        print(("Total number of test examples: {}".format(len(y_test))))
        accuracy = round(count/float(len(y_test)), 4)
        print(("Accuracy: {:g}".format(accuracy)))
        corr = round(np.corrcoef(all_predictions,y_test)[0,1], 4)
        print ("Correlation : ",corr)

    # Save the evaluation to a csv
    print(len(time_period))
    print(len(x_raw))
    print(len(all_predictions))
    print(len(y_test))
    predictions_human_readable = np.column_stack((np.array(time_period), np.array(x_raw), np.array(all_predictions),np.array(y_test)))
    out_path = os.path.join(checkpoint_dir, "..", "prediction.csv")
    print(("Saving evaluation to {0}".format(out_path)))
    with open(out_path, 'w') as f:
        csv.writer(f).writerows(predictions_human_readable)
    return accuracy, all_predictions, all_predictions_binary, corr

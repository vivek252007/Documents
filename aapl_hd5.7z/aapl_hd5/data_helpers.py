import numpy as np
import re
import itertools, h5py
from collections import Counter, OrderedDict
from openpyxl import Workbook,load_workbook
from datetime import datetime, timedelta
import word2vec as w2v

####################################################################################################
####################################################################################################

def get_test_train_data(file_name, test_train_file, len_data, dev_sample_percentage = 0.1):
    dev_sample_index = -1 * int(dev_sample_percentage * float(len_data))
    h5f = h5py.File(file_name,'r')
    h5f_dataSplit = h5py.File(test_train_file,'w')
    test_data_len = h5f['input_text'][:dev_sample_index].shape[0]
    dev_data_len = h5f['input_text'][dev_sample_index:].shape[0]
    h5f_dataSplit.create_dataset('x_train', data=h5f['input_text'][:dev_sample_index])
    h5f_dataSplit.create_dataset('y_train', data=h5f['input_sentiment'][:dev_sample_index])
    h5f_dataSplit.create_dataset('x_dev', data=h5f['input_text'][dev_sample_index:])
    h5f_dataSplit.create_dataset('y_dev', data=h5f['input_sentiment'][dev_sample_index:])
    h5f_dataSplit.create_dataset('date_time_dev', data=h5f['date_time_list'][dev_sample_index:])
    h5f.close()
    h5f_dataSplit.close()
    return test_data_len, dev_data_len

'''**********************************************************************************************'''

def news_weight_dist(period):
    from scipy.stats import skewnorm
    from scipy.stats import gamma
    a=1.5
    x = np.linspace(0,1,period)
    dist = gamma.pdf(x, a,0,0.13)
    dist = dist/period
    # print (dist/sum(dist))
    return (dist/sum(dist))

'''**********************************************************************************************'''

def work_days(ws_o):
    wrk_days = []
    for date in range(ws_o.max_row-1):
        date_o = datetime.strptime(str(ws_o['A'+str(date+2)+''].value).split('.')[0], '%Y-%m-%d %H:%M:%S')
        if date_o.date() not in wrk_days:
            wrk_days.append(date_o.date())
    return wrk_days

'''**********************************************************************************************'''

def get_sentiment_val(ws_o, date_i, time_mins, ret_val, stock_time):
    # print('Format Input Date : ',format(date_i,'%Y-%m-%d %H:%M'))
    stock_price = 0
    for j in range(ws_o.max_row-1):
        # print ('Date sentival  :  ',(str(ws_o['A'+str(j+2)+''].value).split('.')[0]))
        date_o = datetime.strptime(str(ws_o['A'+str(j+2)+''].value).split('.')[0], '%Y-%m-%d %H:%M:%S')
        # print ('Date Output : ', format(date_o,'%Y-%m-%d %H:%M'))
        if format(date_o,'%Y-%m-%d %H:%M') == format(date_i,'%Y-%m-%d %H:%M'):
            # print ('Date sentival  :  ',(str(ws_o['A'+str(j+2)+''].value).split('.')[0]))
            stock_price = float(ws_o['B'+str(j+2)+''].value)
            ret_val = [float(ws_o['C'+str(j+2+x)+''].value) if ws_o['C'+str(j+2+x)+''].value else 0 for x in range(time_mins)]
            break
    return ret_val, stock_price

'''**********************************************************************************************'''

def sentiment_score(ws_o, date_i, date_next, time_mins, wrk_days, last,i):
    ret_val, stock_time, get_data = [],0,True
    # All single headlines within trading day and time i.e. Monday - Friday 9:30 to 4:29
    if (date_i.date() in wrk_days) and (date_i.time() >= datetime.strptime('9:30', '%H:%M').time()) and (date_i.time() <=datetime.strptime('16:00', '%H:%M').time()):
        # print('This is it.')
        ret_val, stock_time = get_sentiment_val(ws_o, date_i, time_mins, ret_val, stock_time)
        get_data = False
    if get_data:
        # For the days when next day is a working day
        date_tomm = datetime.combine((date_i + timedelta(days = 1)).date() , datetime.strptime('09:30', '%H:%M').time())
        if (date_next.date() in wrk_days) and (date_next.time() >= datetime.strptime('9:30', '%H:%M').time()) and (date_next.time() <=datetime.strptime('16:00', '%H:%M').time()):
            if (datetime.combine(date_tomm.date() , datetime.strptime('00:00', '%H:%M').time()) > date_i > datetime.combine(date_i.date() , datetime.strptime('16:00', '%H:%M').time())):
                ret_val, stock_time = get_sentiment_val(ws_o, date_tomm, time_mins, ret_val, stock_time)
            else :
                ret_val, stock_time = get_sentiment_val(ws_o, datetime.strptime(str(date_i.date()) + ' 9:30', '%Y-%m-%d %H:%M'), time_mins, ret_val, stock_time)
        if i == last:
            if (datetime.combine(date_tomm.date() , datetime.strptime('00:00', '%H:%M').time()) > date_i > datetime.combine(date_i.date() , datetime.strptime('16:00', '%H:%M').time())):
                ret_val, stock_time = get_sentiment_val(ws_o, date_tomm, time_mins, ret_val, stock_time)
            else :
                ret_val, stock_time = get_sentiment_val(ws_o, datetime.strptime(str(date_i.date()) + ' 9:30', '%Y-%m-%d %H:%M'), time_mins, ret_val, stock_time)
    return ret_val, stock_time, get_data

'''**********************************************************************************************'''

def load_data(data_file, output_file, time_mins, article_text = True):
    wb_i,wb_o = load_workbook(data_file), load_workbook(output_file,data_only = True)
    ws_i,ws_o = wb_i.active, wb_o.active
    weight_dist = news_weight_dist(time_mins)
    # print (weight_dist)
    wrk_days = work_days(ws_o)
    # print(wrk_days)
    input_text, input_sentiment, text_data, date_time_list, stock_price_list = [],[], '', [],[]
    for i in range(ws_i.max_row-2):
        print ('Row No. : ', i, '/',ws_i.max_row-3)
        last = ws_i.max_row-3
        dateTime_today = str(ws_i['A'+str(i+2)+''].value).split('.')[0]
        dateTime_tommo = str(ws_i['A'+str(i+3)+''].value).split('.')[0]
        date_i = datetime.strptime(dateTime_today.rstrip(), '%Y-%m-%d %H:%M:%S')
        date_next = datetime.strptime(dateTime_tommo.rstrip(), '%Y-%m-%d %H:%M:%S')
        headline = str(ws_i['B'+str(i+2)+''].value)
        # print ('\n\n=> News : ',headline.encode('utf8'))
        # print (date_next)
        text = str(ws_i['C'+str(i+2)+''].value)
        if article_text:
            text_data +=' '+ headline + ' ' + text
        else :
            text_data +=' '+ headline

        ret_val,stock_price, get_data = sentiment_score(ws_o, date_i, date_next, time_mins, wrk_days, last, i)
        # print ("RET VAL : ", len(ret_val))
        if ret_val:
            # print ('ret val true')
            # ret_val = np.array(ret_val,dtype=float)
            # ret_val = [i/sum(abs(ret_val)) for i in ret_val]
            ret_val = np.array(ret_val,dtype=float)
            senti_val = np.sum(np.multiply(weight_dist, ret_val))
            input_text.append(text_data.encode('utf8')) 
            input_sentiment.append(senti_val*1000)
            date_temp = date_i
            weekend = False
            for _ in range(7):
                if date_temp.date() in wrk_days:
                    if (date_temp.time() > datetime.strptime('16:00', '%H:%M').time()) and (weekend == False):
                        date_temp+= timedelta(days=1)
                    break
                else:
                    weekend = True
                    date_temp+= timedelta(days=1)
            # print('date_temp : ', date_temp)
            date_next_list = datetime.combine(date_temp.date() , datetime.strptime('09:30', '%H:%M').time())
            # print('date_next_list : ', date_next_list)
            date_time = format( date_next_list, '%Y-%m-%d %H:%M') if get_data else format(date_i, '%Y-%m-%d %H:%M')
            # print(date_time)
            date_time_list.append(str(date_time).encode('utf8'))
            stock_price_list.append(stock_price)
            # print ('Sentiment : ',senti_val)
            text_data= ''
        else :
            pass
    return input_text, input_sentiment, date_time_list, stock_price_list

####################################################################################################
####################################################################################################

def get_time_period(time_period_news, output_file):
    wb_o = load_workbook(output_file,data_only = True)
    ws_o =  wb_o.active
    work_day = work_days(ws_o)
    time_period,stock_prices = [],[]
    start_date = datetime.strptime(time_period_news[0].decode('utf8'), '%Y-%m-%d %H:%M')
    end_date = datetime.strptime(time_period_news[-1].decode('utf8'), '%Y-%m-%d %H:%M')
    print ('Start Date : ',start_date)
    for _ in range(7):
        if end_date.date() in work_day:
            end_date += timedelta(hours = 4)
            break
        else :
            end_date+= timedelta(days=1)
            end_date = datetime.combine(end_date.date() , datetime.strptime('09:30', '%H:%M').time())
    print ('End Date', end_date)

    for i in range(ws_o.max_row-2):
        dateTime_today = str(ws_o['A'+str(i+2)+''].value).split('.')[0]
        date_i = datetime.strptime(dateTime_today, '%Y-%m-%d %H:%M:%S')
        # print ('date_ i: ',date_i)
        if start_date <= date_i <= end_date:
            # print ('Time appended : ', format(date_i, '%Y-%m-%d %H:%M'))
            time_period.append(format(date_i, '%Y-%m-%d %H:%M'))
            stock_prices.append(float(ws_o['C'+str(i+2)+''].value))
    # print (time_period)
    time_period_clear, stock_prices_clear, remove_dub = [], [], []
    for i in range(len(time_period)):
        if time_period[i] not in remove_dub:
            remove_dub.append(time_period[i])
            time_period_clear.append(time_period[i])
            stock_prices_clear.append(stock_prices[i])
        else :
            # print ('Dublicate Found : ', time_period[i])
            pass
    return time_period_clear, stock_prices_clear

####################################################################################################
####################################################################################################

def load_test_train_data(x_train, y_train, include_text, embedding_dim, word_vec, vec_filename, dev_sample_percentage, impact_time_period, max_length_vec):
    print("Loading data...")
    vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec)
    x, max_doc_len = [],0
    for sentences in x_train:
        temp =[]
        for words in sentences.split():
            words = words.decode('utf8')
            try:
                temp.append(vocab[words])
            except KeyError as e:
                print('Adding missing word to the vocabulary==> %s' % str(e))
                word_vec = w2v.create_vector(words, embedding_dim, word_vec, vec_filename)
                vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec)
                temp.append(vocab[words])
        x.append(temp)
    # print ('max length vector: ', max_length_vec)
    length = max_length_vec if max_length_vec else len(sorted(x, key=len, reverse=True)[0])
    # print('length : ', length)
    x_data = np.array([xi+[0]*(length-len(xi)) for xi in x])
    y_data = np.array(y_train).reshape((len(y_train), 1))
    # print('\n\nINPUT DATA : ', x_data)
    # print ('\n\nOUTPUT DATA : ', y_data)
    if max_length_vec:
        # Map data into vocabulary
        print("\nEvaluating...\n")
        return x_data, y_data
    else :
        # Split train/test set
        # TODO: This is very crude, should use cross-validation
        dev_sample_index = -1 * int(dev_sample_percentage * float(len(y_data)))
        x_train, x_dev = x_data[:dev_sample_index], x_data[dev_sample_index:]
        y_train, y_dev = y_data[:dev_sample_index], y_data[dev_sample_index:]
        y_dev = np.array(y_dev).reshape((len(y_dev), 1))
        return x_train, x_dev, y_train, y_dev, np.array(word2vec), length

####################################################################################################
####################################################################################################

def batch_iter(data, batch_size, num_epochs, shuffle=False):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int((len(data)-1)/batch_size) + 1
    print ('NUMBER OF BATCHES : ', num_batches_per_epoch)
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]
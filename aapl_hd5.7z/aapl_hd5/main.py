import word2vec, train, evaluate, plot_sentiment, clean_data, plot_sentiment_binary
import data_helpers as dh
import tensorflow as tf
import word2vec as w2v
import os.path, shutil, math, h5py
import numpy as np
import pandas as pd

# query="""select a.storyidentifier, a.storytime, a.tickers ,a.storyheadline ,b.bodytext from
# t_bb_news_story_analytics_v2 as a inner join t_bb_story_text_indexed as b on
# a.storyidentifier=b.storyidentifier where tickers = """+ticker+""" and storyheadline <> 'na' and bodytext <> 'na' order by storytime asc LIMIT 10000000"""

# query = """select c.eid ,a.storyidentifier, a.storytime, a.tickers ,a.storyheadline ,b.bodytext from
# t_bb_news_story_analytics_v2 as a inner join t_bb_story_text_indexed as b on
# a.storyidentifier=b.storyidentifier inner join t_bb_news_topic_meta as c on a.storyidentifier=c.storyidentifier where tickers = """+ticker+""" and eid in ('37183','37184','54418') and storyheadline <> 'na' and bodytext <> 'na' order by storytime asc LIMIT 50000"""

# query = """select eid from t_bb_news_topic_meta where storyidentifier = 'MXCKRP6TTDSQ'"""


# KZIS2F1A1I4I 
# KZJOT00UQVI9 
# KZFKP30YHQ0X 

####################################################################################################
dirs = ["data", "temp_data", "temp_npz", "temp_npz/word2vec_npz", "temp_npz/train_npz", "temp_npz/eval_npz"]
for directory in dirs:
	if not os.path.exists(directory):
	    os.makedirs(directory)
data_folder = os.path.join(os.getcwd(),'..','aapl_data')
cleaned_data = os.path.join(data_folder, "AAPL_cleaned.xlsx")
no_slices = 20
####################################################################################################
# DEFINE PARAMETERS
####################################################################################################

# Data loading params
tf.flags.DEFINE_float("dev_sample_percentage", .1, "Percentage of the training data to use for validation (default: 0.1)")
tf.flags.DEFINE_string("vec_filename", "data/glove.6B.300d.txt", "Data source for the word vectors data") 
tf.flags.DEFINE_string("input_filename", os.path.join(data_folder, "AAPL.xlsx"), "Data source for the input headlines data")
tf.flags.DEFINE_string("output_filename", os.path.join(data_folder, "AAPL_stock.xlsx"), "Data source for the sentiment of the headlines")

tf.flags.DEFINE_string("temp_input_data", "temp_npz/clean_input_data.hdf5", "temporary cleaned input data")
tf.flags.DEFINE_string("temp_test_train_input_data", "temp_npz/train_test_data.hdf5", "test and train data")

tf.flags.DEFINE_string("temp_word2vec_data", "temp_npz/word2vec_npz/word2vec_embed_data.hdf5", "temporary input data ready for training")
tf.flags.DEFINE_string("temp_word2vec_embed", "temp_npz/word2vec_npz/word2vec_trained_embed.hdf5", "temporary input data ready for training")

tf.flags.DEFINE_string("temp_train_data", "temp_npz/train_npz/train_data.hdf5", "temporary input data ready for training") 
tf.flags.DEFINE_string("train_out_data", 'temp_npz/train_npz/train_out.npz', "temporary input data ready for plotting")

tf.flags.DEFINE_string("temp_test_data", "temp_npz/eval_npz/test_data.hdf5", "temporary input data ready for testing")
tf.flags.DEFINE_string("temp_out_data", "temp_npz/eval_npz/output_data.npz", "temporary input data ready for plotting")

'''**********************************************************************************************'''

# WordVec Model Hyperparameters
tf.flags.DEFINE_integer("embedding_size", 10, "Dimensionality of character embedding (default: 300)")
tf.flags.DEFINE_integer("num_steps", 1001, "number of steps to train the model")

# WordVec Training Parameters
tf.flags.DEFINE_integer("batch_size_vec", 300,"Size of the batch for training word vectors")
tf.flags.DEFINE_integer("skip_window", 7,"How many words to consider left and right.")
tf.flags.DEFINE_integer("num_skips", 2,"How many times to reuse an input to generate a label.")
tf.flags.DEFINE_integer("num_sampled", 64 ,"Number of negative examples to sample. (default: 64)")

'''**********************************************************************************************'''

# CNN Model Hyperparameters
tf.flags.DEFINE_integer("impact_time_period", 240, "News impact time period on stock prices (default: 4 hours (240 mins))")
tf.flags.DEFINE_string("filter_sizes", "3,4,5", "Comma-separated filter sizes (default: '3,4,5')")
tf.flags.DEFINE_integer("num_filters", 128, "Number of filters per filter size (default: 128)")
tf.flags.DEFINE_float("dropout_keep_prob", 0.5, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_float("l2_reg_lambda", 0.01, "L2 regularization lambda (default: 0.0)")

# CNN Training parameters
tf.flags.DEFINE_integer("batch_size", 6, "Batch Size (default: 60)")
tf.flags.DEFINE_integer("num_epochs", 5, "Number of training epochs (default: 200)")
tf.flags.DEFINE_integer("evaluate_every", 10, "Evaluate model on dev set after this many steps (default: 100)")
tf.flags.DEFINE_integer("checkpoint_every", 10, "Save model after this many steps (default: 100)")
tf.flags.DEFINE_integer("num_checkpoints", 5, "Number of checkpoints to store (default: 5)")
tf.flags.DEFINE_boolean("include_text", False, "Include body text data of the article during training")

'''**********************************************************************************************'''

# Evaluation Parameters
tf.flags.DEFINE_integer("accuracy_range", 1, "Range within which the predicted sentiment value should be with actual value to be accurate (default: 0.2)")

'''**********************************************************************************************'''

# Misc Parameters
tf.flags.DEFINE_integer("vocabulary_size", 5000000, "Initial estimated size of the vocabulary")
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")


FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:\n")
for attr, value in sorted(FLAGS.__flags.items()):
    print(("{}={}".format(attr.upper(), value)))
print("")

####################################################################################################
# CLAEN AND GET DATA
'''**********************************************************************************************'''

if not os.path.isfile(cleaned_data):
	clean_data.get_data(FLAGS.input_filename, data_folder)
len_data = clean_data.multiprocess_data(cleaned_data, FLAGS.output_filename, FLAGS.temp_input_data, FLAGS.impact_time_period, FLAGS.include_text)
test_data_len, dev_data_len = dh.get_test_train_data(FLAGS.temp_input_data, FLAGS.temp_test_train_input_data, len_data, FLAGS.dev_sample_percentage)

total_data_len = test_data_len+dev_data_len
shutil.rmtree('temp_data/')
# FLAGS.temp_input_data = "temp_npz/temp_input_data_text.npz"

# ####################################################################################################


# ####################################################################################################
# # UPDATE WORD VECTORS
'''**********************************************************************************************'''
h5f = h5py.File(FLAGS.temp_input_data,'r')
input_text = h5f['input_text']
vocabulary =  word2vec.read_data(input_text)
data, count, dictionary, reverse_dictionary, vocabulary_size = word2vec.build_dataset(vocabulary, FLAGS.vocabulary_size)
del vocabulary, input_text, dictionary, count 
h5f.close()
file_present = os.path.isfile(FLAGS.vec_filename )
embeddings, train_w2v = word2vec.create_embeddings(file_present, vocabulary_size, FLAGS.embedding_size, FLAGS.vec_filename, reverse_dictionary)

save_word2vec_file = FLAGS.temp_word2vec_data.split('.')[0] + '_text.hdf5' if FLAGS.include_text else FLAGS.temp_word2vec_data
np.save('temp_npz/word2vec_npz/reverse_dictionary.npy',np.array([reverse_dictionary]))
h5f = h5py.File(save_word2vec_file, 'w')
h5f.create_dataset('embeddings', data=embeddings)
h5f.create_dataset('data', data=data)
h5f.create_dataset('vocabulary_size', data=vocabulary_size)
h5f.create_dataset('train_w2v', data=train_w2v)
h5f.close()
del embeddings, train_w2v, reverse_dictionary, data

'''**********************************************************************************************'''
h5f = h5py.File(save_word2vec_file,'r')
embeddings = h5f['embeddings'].value
data = h5f['data']
vocabulary_size = h5f['vocabulary_size'].value
train_w2v = h5f['train_w2v'].value
reverse_dictionary = np.load('temp_npz/word2vec_npz/reverse_dictionary.npy')[0]
if train_w2v:
	labels, final_embeddings = word2vec.build_graph_run_graph(embeddings, FLAGS.embedding_size, vocabulary_size, FLAGS.batch_size_vec,
		FLAGS.num_skips, FLAGS.skip_window, FLAGS.num_sampled, FLAGS.num_steps, data, reverse_dictionary)
	h5f.close()
	h5f = h5py.File(FLAGS.temp_word2vec_embed, 'w')
	h5f.create_dataset('labels', data=labels)
	h5f.create_dataset('final_embeddings', data=final_embeddings)
	h5f.close()

	h5f = h5py.File(FLAGS.temp_word2vec_embed, 'r')
	labels = h5f['labels'].value
	final_embeddings = h5f['final_embeddings']
	word_vec_temp = word2vec.create_new_vec(labels, final_embeddings, file_present, FLAGS.vec_filename, FLAGS.embedding_size)
	h5f.close()
	word2vec.create_vec_file(word_vec_temp, FLAGS.vec_filename)
	del word_vec_temp, labels, final_embeddings
del embeddings, data, reverse_dictionary, vocabulary_size, train_w2v

####################################################################################################


####################################################################################################
# TRAIN THE MODEL
'''**********************************************************************************************'''

word_vec_temp = w2v.load_glove(FLAGS.vec_filename, FLAGS.embedding_size)
h5f = h5py.File(FLAGS.temp_test_train_input_data,'r')
for i in h5f.items():
	print(i)
x_train = h5f['x_train']
y_train = h5f['y_train']

x_train_data, x_dev, y_train_data, y_dev, word2vec, max_length_vec = dh.load_test_train_data(x_train, y_train,
	FLAGS.include_text, FLAGS.embedding_size, word_vec_temp, FLAGS.vec_filename, FLAGS.dev_sample_percentage, FLAGS.impact_time_period, False)
print(x_train_data.shape, y_train_data.shape)
del word_vec_temp
h5f.close()

save_train_file = FLAGS.temp_train_data.split('.')[0] + '_text.hdf5' if FLAGS.include_text else FLAGS.temp_train_data
h5f = h5py.File(save_train_file,'w')
h5f.create_dataset('x_train_data', data=x_train_data)
h5f.create_dataset('x_dev', data=x_dev)
h5f.create_dataset('y_train_data', data=y_train_data)
h5f.create_dataset('y_dev', data=y_dev)
h5f.create_dataset('word2vec', data= word2vec)
h5f.create_dataset('max_length_vec', data=max_length_vec)
h5f.close()
del x_train, x_dev, y_train, y_dev, word2vec, max_length_vec

'''**********************************************************************************************'''
h5f = h5py.File(save_train_file,'r')
print (h5f)
for i in h5f.items():
	print(i)
x_train = h5f['x_train_data']
x_dev = h5f['x_dev']
y_train = h5f['y_train_data']
y_dev = h5f['y_dev']
word2vec = h5f['word2vec']
max_length_vec = h5f['max_length_vec'].value

out_dir = train.train_model(x_train, x_dev, y_train, y_dev, word2vec, FLAGS.allow_soft_placement, FLAGS.log_device_placement,
	FLAGS.embedding_size, FLAGS.filter_sizes, FLAGS.num_filters, FLAGS.l2_reg_lambda, FLAGS.num_checkpoints,
	FLAGS.dropout_keep_prob, FLAGS.batch_size, FLAGS.num_epochs, FLAGS.evaluate_every, FLAGS.checkpoint_every)
h5f.close()
out_dir =  'runs/'+str(out_dir).split("runs")[-1][1:]+'/checkpoints/'
print ('THE MODEL DIRECTORY IS : ', out_dir)
print ('MAX LENGTH VECTOR : ', max_length_vec)
np.savez(FLAGS.train_out_data, out_dir=out_dir, max_length_vec=max_length_vec)
del x_train, y_train, x_dev, y_dev, word2vec, max_length_vec

# ####################################################################################################


# ####################################################################################################
# # EVALUATE THE MODEL AND PRINT RESULTS
# '''**********************************************************************************************'''

word_vec_temp = w2v.load_glove(FLAGS.vec_filename, FLAGS.embedding_size)
max_length_vec = int(np.load(FLAGS.train_out_data)['max_length_vec'])
# out_dir = "runs/1494941045/checkpoints/"
# max_length_vec = 422 
# print (out_dir)
h5f = h5py.File(FLAGS.temp_test_train_input_data,'r')
x_test = h5f['x_dev']
y_test = h5f['y_dev']

x_test_data, y_test_data= dh.load_test_train_data(x_test, y_test,
	FLAGS.include_text, FLAGS.embedding_size, word_vec_temp, FLAGS.vec_filename, FLAGS.dev_sample_percentage, FLAGS.impact_time_period, max_length_vec)
h5f.close()

del word_vec_temp

save_test_file = FLAGS.temp_test_data.split('.')[0] + '_text.hdf5' if FLAGS.include_text else FLAGS.temp_test_data
h5f = h5py.File(save_test_file,'w')
h5f.create_dataset('x_test_data', data=x_test_data)
h5f.create_dataset('y_test_data', data=y_test_data)
h5f.close()

# '''**********************************************************************************************'''

h5f = h5py.File(save_test_file,'r')
x_test = h5f['x_test_data']
y_test = h5f['y_test_data']
h5f_raw = h5py.File(FLAGS.temp_test_train_input_data,'r')
x_raw = h5f_raw['x_dev']

out_dir = str(np.load(FLAGS.train_out_data)["out_dir"])

h5f_org = h5py.File(FLAGS.temp_test_train_input_data,'r')
time_period_news = h5f_org['date_time_dev']

print('Out dir : ', out_dir)

percent_accuracy, sentiments, sentiments_binary, corr = evaluate.model_evaluation(x_test, y_test, out_dir,
	FLAGS.allow_soft_placement, FLAGS.log_device_placement, FLAGS.batch_size, x_raw, FLAGS.accuracy_range, time_period_news)

time_period, stock_prices = dh.get_time_period(time_period_news, FLAGS.output_filename)


save_out_file = FLAGS.temp_out_data.split('.')[0] + '_text.npz' if FLAGS.include_text else FLAGS.temp_out_data
# h5f = h5py.File(save_out_file,'w')
# h5f.create_dataset('time_period', data=time_period)
# h5f.create_dataset('time_period_news', data=time_period_news)
# h5f.create_dataset('stock_prices', data=stock_prices)
# h5f.create_dataset('sentiments', data=sentiments)
# h5f.create_dataset('sentiments_binary', data=sentiments_binary)
# h5f.create_dataset('percent_accuracy', data=percent_accuracy)
# h5f.create_dataset('corr', data=corr)
# h5f.create_dataset('x_raw', data=x_raw)
# h5f.close()

np.savez(save_out_file, time_period = np.array(time_period), time_period_news = np.array(time_period_news.value), 
	stock_prices = np.array(stock_prices), sentiments = np.array(sentiments), sentiments_binary = np.array(sentiments_binary),
	percent_accuracy = np.array(percent_accuracy), corr = np.array(corr), x_raw = np.array(x_raw.value))
h5f_org.close()
h5f.close()
h5f_raw.close()
# '''**********************************************************************************************'''

# np_data_out = np.load(save_out_file)
# time_period = np_data_out['time_period'].tolist()
# time_period_news = np_data_out['time_period_news'].tolist()
# stock_prices = np_data_out['stock_prices'].tolist()
# sentiments = np_data_out['sentiments'].tolist()
# sentiments_binary = np_data_out['sentiments_binary'].tolist()
# percent_accuracy = float(np_data_out['percent_accuracy'])
# corr = float(np_data_out['corr'])
# x_raw = np_data_out['x_raw'].tolist()

# del save_out_file, np_data_out

# plot_sentiment.plot_sentiment(time_period = time_period, time_period_news = time_period_news, stock_prices = stock_prices, 
# 	sentiment_values = sentiments, news_headlines = x_raw, corr_value =  corr*100)

# plot_sentiment_binary.plot_sentiment(time_period = time_period, time_period_news = time_period_news, stock_prices = stock_prices, 
# 	sentiment_values = sentiments_binary, news_headlines = x_raw, percent_accuracy =  percent_accuracy*100)

####################################################################################################

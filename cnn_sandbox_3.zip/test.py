# import csv, re, json, math
# from openpyxl import load_workbook, Workbook
# from datetime import datetime
# from datetime import date
import data_helpers as dh
import word2vec as w2v
import tensorflow as tf
import numpy as np

embedding_dim = 300
vec_filename = "data/glove.6B.300d.txt"
word_vec_temp = w2v.load_glove(vec_filename, embedding_dim)
# for key, value in word_vec_temp.items():
# 	print (key.encode('utf8'))
vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec_temp)
for key,value in vocab.items():
	word_vec_temp[str(key)]
# peace = vocab["Apple's"]
# print ()

# time_period_news = ['2017-04-03 15:43', '2017-04-03 15:57', '2017-04-03 15:58', '2017-04-03 15:58']
# print (dh.get_time_period(time_period_news, "data/AAPL_stock.xlsx"))

# a = w2v.load_glove("data/glove.6B.300d.txt", 300)
# vocab, word_vec = w2v.process_vocab(300, a)
# for value in word_vec:
# 	print (len(value))
# SCores :  [array([[-0.21065091], [ 0.04515348], [-0.06944293]], dtype=float32)]

# input_y = np.array([ 0.48442711, 0.48442711,0.09758418 ])
# scores = np.array([-4.99550438, -4.96850014, -4.86017132])
# losses = tf.losses.mean_squared_error(predictions = scores, labels = input_y)
# sess = tf.Session()
# loss = sess.run(losses, )
# print(loss)

# def clean_json():
# 	with open('blk_minute','r') as f:
# 		a = f.read()
# 		a = a.split('}')
# 		a = list(filter(None, a))
# 		while ' ' in a:
# 			a.remove(' ')
# 	with open('blk_minute_clean','w') as f:
# 		for json_obj in a:
# 			# print(json_obj)
# 			if json_obj != None:
# 				f.write(json_obj+'}\n')

# def get_ouptut_data():
# 	wb = Workbook()
# 	ws = wb.active
# 	time_stamps, price_list = [],[]
# 	ws.cell(row=1,column=1).value ='Date'
# 	ws.cell(row=1,column=2).value = 'Stock Price'
# 	ws.cell(row=1,column=3).value = 'Returns'
# 	with open('blk_minute_clean','r') as f:
# 	    for idx,line in enumerate(f):
# 	        while True:
# 	            try:
# 	                jfile = json.loads(line)
# 	                try:
# 	                	for time_str in jfile['TIMESTAMP']:
# 	                		time_stamps.append(datetime.fromtimestamp(int(time_str[:-3])))
# 	                	for price_str in jfile['MINUTE_PRICE']:
# 	                		price_list.append(price_str)
# 	                	# print (jfile['MINUTE_PRICE'])
# 	                except:
# 	                	pass
# 	                break
# 	            except ValueError:
# 	                # Not yet a complete JSON value
# 	                line += next(f)
# 	for idx in range(len(time_stamps)):
# 		ws.cell(row=idx+2,column=1).value = time_stamps[idx]
# 		ws.cell(row=idx+2,column=2).value = price_list[idx]
# 		if idx !=0:
# 			ws.cell(row=idx+2,column=3).value = math.log(float(price_list[idx])/float(price_list[idx-1]))
# 	# print (time_stamps)
# 	# print (price_list)
# 	filename = 'output_data.xlsx'
# 	wb.save(filename=filename)
# 	time_price = dict(zip(time_stamps, price_list))

# clean_json()
# get_ouptut_data()

# {'MINUTE_PRICE': ['234.920000', '235.606689', '237.997500'], '_SYMBOL_NAME': 'TAQ::BLK', 'TIMESTAMP': ['1262615460000', '1262615520000', '1262615580000'], 'MSG_TYPE': 'PROCESS_EVENT', 'CALLBACK_ID': 6}
# {'MINUTE_PRICE': ['238.080000', '238.076429'], '_SYMBOL_NAME': 'TAQ::BLK', 'TIMESTAMP': ['1262635080000', '1262635140000'], 'MSG_TYPE': 'PROCESS_EVENT', 'CALLBACK_ID': 6}
# {'NUM_FIELDS': 1, 'FIELD_NAMES': ['MINUTE_PRICE'], 'FIELD_TYPES': ['TYPE_DOUBLE'], 'MSG_TYPE': 'PROCESS_TICK_DESCRIPTOR', 'CALLBACK_ID': 6}


##########################################################################################
# CLEANING THE BLOOMBERG DATABSE
##########################################################################################

# def clean_text(text_str):
# 	text = ''
# 	for word in text_str.split():
# 		text += word+' '
# 	return text

# def excel_to_csv():
# 	wb = Workbook()
# 	ws = wb.active
# 	with open('data/database_blk.csv', encoding = 'utf8') as f:
# 		reader = csv.reader(f, delimiter='|')
# 		storyIdentifiers_list,row_no = [],0
# 		for row_id, row in enumerate(reader):
# 			text_data = ''
# 			# print ('Row length : ', len (row[0].split(',')))
# 			if len(row[0].split(','))>1:
# 				storyIden = row[0].split(',')[1]
# 				if storyIden not in storyIdentifiers_list:
# 					storyIdentifiers_list.append(storyIden)
# 					row_no +=1
# 					print ('Row : ',row_no, ' Original : ', storyIden)
# 					for idx,blk_data in enumerate(row[0].split(',')):
# 						if (idx>4) and (idx < len(row[0].split(','))-1):
# 							text_data += str(blk_data) + ' '
# 						elif idx == len(row[0].split(','))-1:
# 							ws.cell(row=row_no,column=6).value = clean_text(str(text_data))
# 						else :
# 							ws.cell(row=row_no,column=idx+1).value = clean_text(str(blk_data))
# 				else :
# 					print ('Row : ',row_id, ' DUBLICATE : ', storyIden)
# 			else :
# 				print ('\nBad Data -> ',row[0].split(','))
# 			# if row_id == 5:
# 			# 	break
# 	filename = 'data.xlsx'
# 	wb.save(filename=filename)

# excel_to_csv()

##########################################################################################
# CHANGE TH EFROMAT OF THE DATE IN EXCEL
##########################################################################################

# def change_excel(data_file):
#     wb = load_workbook(data_file)
#     ws = wb['AAPL NEWS']
#     # ws_i = wb_i['Sheet1']
#     for i in range(ws.max_row -1):
#         date_obj = datetime.strptime(str(ws['A'+str(i+2)+''].value)[:10]+' '+str(ws['B'+str(i+2)+''].value),'%Y-%m-%d %H:%M:%S')
#         print (date_obj)
#         ws['A'+str(i+2)+''] = date_obj
#     wb.save(data_file)

# change_excel('data/AAPL.xlsx')
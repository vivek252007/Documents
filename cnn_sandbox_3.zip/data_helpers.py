import numpy as np
import re
import itertools
from collections import Counter, OrderedDict
from openpyxl import Workbook,load_workbook
from datetime import datetime, timedelta
import word2vec as w2v

####################################################################################################
####################################################################################################

def news_weight_dist(period):
    from scipy.stats import skewnorm
    from scipy.stats import gamma
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 1)
    a=1.5
    x = np.linspace(0,1,period)
    dist = gamma.pdf(x, a,0,0.13)
    # print (dist/period)
    # print (np.sum(dist)/period)
    # ax.plot(x, dist,'r-', lw=3, alpha=1, label='skewnorm pdf')
    # plt.show()
    return (dist/period)

####################################################################################################
####################################################################################################

def work_days(ws_o):
    wrk_days = []
    for date in range(ws_o.max_row-1):
        date_o = datetime.strptime(str(ws_o['A'+str(date+2)+''].value).split('.')[0], '%Y-%m-%d %H:%M:%S')
        if date_o.date() not in wrk_days:
            wrk_days.append(date_o.date())
    return wrk_days

####################################################################################################
####################################################################################################

def get_sentiment_val(ws_o, date_i, time_mins, ret_val, stock_time):
    # print('Format Input Date : ',format(date_i,'%Y-%m-%d %H:%M'))
    for j in range(ws_o.max_row-1):
        # print ('Date sentival  :  ',(str(ws_o['A'+str(j+2)+''].value).split('.')[0]))
        date_o = datetime.strptime(str(ws_o['A'+str(j+2)+''].value).split('.')[0], '%Y-%m-%d %H:%M:%S')
        # print ('Date Output : ', format(date_o,'%Y-%m-%d %H:%M'))
        if format(date_o,'%Y-%m-%d %H:%M') == format(date_i,'%Y-%m-%d %H:%M'):
            # print ('Date sentival  :  ',(str(ws_o['A'+str(j+2)+''].value).split('.')[0]))
            stock_time = float(ws_o['B'+str(j+2)+''].value)
            ret_val = [float(ws_o['C'+str(j+2+x)+''].value) if ws_o['C'+str(j+2+x)+''].value else 0 for x in range(time_mins)]
            break
    return ret_val, stock_time

####################################################################################################
####################################################################################################

def sentiment_score(ws_o, date_i, date_next, time_mins, wrk_days, last,i):
    ret_val, stock_time, get_data = [],0,True
    # All single headlines within trading day and time i.e. Monday - Friday 9:30 to 4:29
    if (date_i.date() in wrk_days) and (date_i.time() >= datetime.strptime('9:30', '%H:%M').time()) and (date_i.time() <=datetime.strptime('16:00', '%H:%M').time()):
        # print('This is it.')
        ret_val, stock_time = get_sentiment_val(ws_o, date_i, time_mins, ret_val, stock_time)
        get_data = False
    if get_data:
        # For the days when next day is a working day
        if (date_next.date() in wrk_days) and (date_next.time() >= datetime.strptime('9:30', '%H:%M').time()) and (date_next.time() <=datetime.strptime('16:00', '%H:%M').time()):
            ret_val, stock_time = get_sentiment_val(ws_o, datetime.strptime(str(date_next.date()) + ' 9:30', '%Y-%m-%d %H:%M'), time_mins, ret_val, stock_time)
        if i == last:
            ret_val, stock_time = get_sentiment_val(ws_o, datetime.strptime(str(date_next.date()) + ' 9:30', '%Y-%m-%d %H:%M'), time_mins, ret_val, stock_time)
    return ret_val, stock_time, get_data
####################################################################################################
####################################################################################################

def load_data(data_file, output_file, time_mins, article_text = True):
    wb_i,wb_o = load_workbook(data_file), load_workbook(output_file,data_only = True)
    ws_i,ws_o = wb_i.active, wb_o.active
    weight_dist = news_weight_dist(time_mins)
    wrk_days = work_days(ws_o)
    # print(wrk_days)
    input_x, text_data, date_time_list, stock_price_list = OrderedDict(), '', [], []
    for i in range(ws_i.max_row-2):
        last = ws_i.max_row-3
        dateTime_today = str(ws_i['C'+str(i+2)+''].value).split('.')[0]
        dateTime_tommo = str(ws_i['C'+str(i+3)+''].value).split('.')[0]
        date_i = datetime.strptime(dateTime_today.rstrip(), '%m/%d/%Y %H:%M')
        date_next = datetime.strptime(dateTime_tommo.rstrip(), '%m/%d/%Y %H:%M')
        headline = str(ws_i['E'+str(i+2)+''].value)
        # print ('\n\n=> News : ',headline)
        # print (date_next)
        text = str(ws_i['F'+str(i+2)+''].value)
        if article_text:
        	text_data +=' '+ headline + ' ' + text
        else :
        	text_data +=' '+ headline
        ret_val,stock_time, get_data = sentiment_score(ws_o, date_i, date_next, time_mins, wrk_days, last, i)
        # print ("RET VAL : ", len(ret_val))
        if ret_val:
            # print ('ret val true')
            ret_val = np.array(ret_val,dtype=float)
            ret_val = [i/sum(abs(ret_val)) for i in ret_val]
            ret_val = np.array(ret_val,dtype=float)
            senti_val = np.sum(np.multiply(weight_dist, ret_val))
            input_x[text_data] = senti_val*1000
            date_next_list = datetime.combine(date_next.date() , datetime.strptime('09:30', '%H:%M').time())
            date_time_list.append(format( date_next_list, '%Y-%m-%d %H:%M') if get_data else format(date_i, '%Y-%m-%d %H:%M'))
            stock_price_list.append(stock_time)
            # print ('Sentiment : ',senti_val)
            text_data= ''
        else :
            pass
    return input_x, date_time_list, stock_price_list

####################################################################################################
####################################################################################################

def get_data(data_file, output_file, article_text = True, impact_time_period = 240, dev_sample_percentage = 0.1):
    print ('\n\nget_data data_file : ', data_file)
    x_text, date_time, stock_price = load_data(data_file, output_file, impact_time_period, article_text)
    input_x, input_x_train, input_x_test, y_train, y_test, date_time_list, stock_price_list = [],[],[],[],[],[],[]
    train_range = int((len(x_text)-1)*(1-dev_sample_percentage))
    for idx, (key, value) in enumerate(x_text.items()):
        input_x.append(key)
        if idx <= train_range:
            input_x_train.append(key)
            y_train.append(value)
        else:
            input_x_test.append(key)
            y_test.append(value)  
            date_time_list.append(date_time[idx])
            stock_price_list.append(stock_price[idx])
    return input_x, input_x_train, input_x_test, np.array(y_train), np.array(y_test), date_time_list, stock_price_list

####################################################################################################
####################################################################################################

def get_time_period(time_period_news, output_file):
    wb_o = load_workbook(output_file,data_only = True)
    ws_o =  wb_o.active
    work_day = work_days(ws_o)
    time_period,stock_prices = [],[]
    start_date = datetime.strptime(time_period_news[0], '%Y-%m-%d %H:%M')
    end_date = datetime.strptime(time_period_news[-1], '%Y-%m-%d %H:%M')
    print ('Start Date : ',start_date)
    for _ in range(7):
        if end_date.date() in work_day:
            break
        else :
            end_date+= timedelta(days=1)
            end_date = datetime.combine(end_date.date() , datetime.strptime('09:30', '%H:%M').time()) + timedelta(hours = 4)
    print ('End Date', end_date)
    for i in range(ws_o.max_row-2):
        dateTime_today = str(ws_o['A'+str(i+2)+''].value).split('.')[0]
        date_i = datetime.strptime(dateTime_today, '%Y-%m-%d %H:%M:%S')
        # print ('date_ i: ',date_i)
        if start_date <= date_i <= end_date:
            time_period.append(format(date_i, '%Y-%m-%d %H:%M'))
            stock_prices.append(float(ws_o['B'+str(i+2)+''].value))
    return time_period, stock_prices

####################################################################################################
####################################################################################################

def load_test_train_data(x_raw, y, include_text, embedding_dim, word_vec, vec_filename, dev_sample_percentage, impact_time_period, max_length_vec):
    print("Loading data...")
    vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec)
    x, max_doc_len = [],0
    for sentences in x_raw:
        temp =[]
        for words in sentences.split():
            try:
                temp.append(vocab[words])
            except KeyError as e:
                print('Adding missing word to the vocabulary==> %s' % str(e))
                word_vec = w2v.create_vector(words, embedding_dim, word_vec, vec_filename)
                vocab, word2vec = w2v.process_vocab(embedding_dim, word_vec)
                temp.append(vocab[words])
        x.append(temp)
    # print ('max length vector: ', max_length_vec)
    length = max_length_vec if max_length_vec else len(sorted(x, key=len, reverse=True)[0])
    # print('length : ', length)
    x_data = np.array([xi+[0]*(length-len(xi)) for xi in x])
    y_data = np.array(y).reshape((len(y), 1))
    print('\n\nINPUT DATA : ', x_data)
    print ('\n\nOUTPUT DATA : ', y_data)
    if max_length_vec:
        # Map data into vocabulary
        print("\nEvaluating...\n")
        return x_data, y_data, x_raw
    else :
        # Split train/test set
        # TODO: This is very crude, should use cross-validation
        dev_sample_index = -1 * int(dev_sample_percentage * float(len(y_data)))
        x_train, x_dev = x_data[:dev_sample_index], x_data[dev_sample_index:]
        y_train, y_dev = y_data[:dev_sample_index], y_data[dev_sample_index:]
        y_dev = np.array(y_dev).reshape((len(y_dev), 1))
        return x_train, x_dev, y_train, y_dev, word2vec, length

####################################################################################################
####################################################################################################

def batch_iter(data, batch_size, num_epochs, shuffle=False):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int((len(data)-1)/batch_size) + 1
    print ('NUMBER OF BATCHES : ', num_batches_per_epoch)
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]
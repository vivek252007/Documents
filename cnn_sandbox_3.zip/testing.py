get_ipython().magic(u'matplotlib inline')

import psycopg2
import pprint
import pandas as pd
import pandas.io.sql as psql
import matplotlib
import matplotlib.pyplot as plt
import pickle

configuration = { 'dbname': 'bbnews', 
                  'user':'sae_bbnews',
                  'pwd':'saeBBNew5',
                  'host':'bbnews-qt-redshift.ciyg0rvtqu5l.us-west-2.redshift.amazonaws.com',
                  'port':'8194'
                }
def create_conn(*args,**kwargs):

    config = kwargs['config']
    try:
        conn=psycopg2.connect(dbname=config['dbname'], host=config['host'], port=config['port'], user=config['user'], password=config['pwd'])
    except Exception as err:
        print err.code, err
    return conn

conn = create_conn(config=configuration)
cursor = conn.cursor()

query = """SELECT t1.storyidentifier,t1.tickers,t1.storytime as ,t1.storyheadline,t2.bodytext FROM t_bb_news_story_analytics_v2 t1 
INNER JOIN t_bb_story_text_indexed t2 ON t2.storyidentifier = t1.storyidentifier LIMIT 10000000"""

#database_list = ['bb_news_taxonomy_new_companies','bb_news_taxonomy_securities','t_bb_barra_v_exchange_listing','t_inv_univ_constituent_hist',
#                 't_bb_news_story_analytics','t_bb_company_meta_pre2008_dump','t_bb_topic_meta_pre2008_dump','t_bb_news_story_pre2008_dump',
#                 't_bb_story_text_pre2008_dump','t_bb_news_story_analytics_v2','t_bb_news_company_meta','t_bb_news_company_analytics_indexed',
#                 't_bb_news_company_analytics','t_bb_news_safahus_esg_controversies','bb_news_taxonomy_topics','t_bb_news_topic_meta',
#                 't_bb_news_company_meta_storyid_indexed','t_bb_news_story_analytics_indexed'',kv_test','t_bb_story_text_indexed',
#                 't_map_newstkr_barrid','test_table','t_bb_news_story_company_count','sae_temp_japan_stories_lemmon']
#atabase_list = ['t_bb_news_story_analytics_v2']

#query = """SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"""
#query = """SELECT count(*) AS exact_count FROM t_bb_story_text_indexed"""
#df_raw_copper = psql.read_sql(query, conn)
#query = """SELECT t1.storyidentifier,t1.tickers,t1.storytime,t1.storyheadline,t2.bodytext FROM t_bb_news_story_analytics_v2 t1 
#INNER JOIN t_bb_story_text_indexed t2 ON t2.storyidentifier = t1.storyidentifier LIMIT 10000000"""
#df_raw_copper.to_csv("database_joined.csv", sep='|', encoding='utf-8')
#for i in range(167):
    #query="""SELECT storyidentifier,bodytext FROM t_bb_story_text_indexed LIMIT 1000000 OFFSET """+str(1000000*i)
    #df_raw_copper = psql.read_sql(query, conn)
    #df_raw_copper.to_csv("database_"+str(i)+".csv", sep='|', encoding='utf-8')
    #df_raw_copper.to_csv("database_"+str(i)+".csv", sep='|', encoding='utf-8')
    #del df_raw_copper
#print df_raw_copper


# import data_helpers as dh
# from openpyxl import Workbook,load_workbook
# from datetime import datetime
# import numpy as np

# def change_excel(data_file):
#     wb_i = load_workbook(data_file)
#     ws_i = wb_i['AAPL NEWS']
#     # ws_i = wb_i['Sheet1']
#     for i in range(ws_i.max_row -1):
#         date_obj = datetime.strptime(str(ws_i['A'+str(i+2)+''].value)[:10]+' '+str(ws_i['B'+str(i+2)+''].value),'%Y-%m-%d %H:%M:%S')
#         print (date_obj)
#         ws_i['A'+str(i+2)+''] = date_obj
#     wb_i.save(data_file)

# change_excel('AAPL.xlsx')
# print (dh.load_test("test.xlsx"))
# print (dh.get_data('AAPL.xlsx','AAPL_min.xlsx') )

# def news_weight_dist(period):
#     from scipy.stats import skewnorm
#     from scipy.stats import gamma
#     import matplotlib.pyplot as plt
#     fig, ax = plt.subplots(1, 1)
#     a=1.5
#     x = np.linspace(0,1,period)
#     dist = gamma.pdf(x, a,0,0.13)
#     print (dist/period)
#     print (np.sum(dist)/period)
#     ax.plot(x, dist,'r-', lw=3, alpha=1, label='skewnorm pdf')
#     plt.show()
#     return (dist/period)

# for i in range(ws.max_row-1):
#     headline = str(ws['D'+str(i+2)+''].value)
#     body_text = str(ws['E'+str(i+2)+''].value)
#     text_data += headline +' '+ body_text+' '
# return len(text_data.split()), len(text_data1)  

  '''
Loads the test excel file with 100 headlines marked with positive and negative sentiment
Process the excel file and returns the headline and sentiment
# headlines = ws.columns[3]
# body_text = ws.columns[4]
# with open('data/text8','w') as f:
#     for column in headlines:
#         f.write(str(column.value) if not None else '')
#     for column in body_text:
#         f.write(str(column.value) if not None else '')


Evaluation Done ...
Saved model checkpoint to C:\Users\vkhajuri.BLACKROCK\VirtualBox VMs\vmshared\NLP_DL\algo\cnn_sandbox_2\runs\1493840535\checkpoints\model-800

==> loading glove
==> glove is loaded
THE MODEL DIRECTORY IS :  runs/1493840535/checkpoints/
MAX LENGTH VECTOR :  1279
Loading data...


get_data data_file :  data/AAPL_test.xlsx
[datetime.date(2017, 3, 31), datetime.date(2017, 4, 3), datetime.date(2017, 4, 4), datetime.date(2017, 4, 5), datetime.date(2017, 4, 6), datetime.date(2017, 4, 7), datetime.date(2017, 4, 10), datetime.date(2017, 4, 11), datetime.date(2017, 4, 12), datetime.date(2017, 4, 13), datetime.date(2017, 4, 17), datetime.date(2017, 4, 18), datetime.date(2017, 4, 19), datetime.date(2017, 4, 20), datetime.date(2017, 4, 21)]
==> vocab processing is done with vocab, word2vec length :  400315 400315


INPUT DATA :  (30, 1279)


OUTPUT DATA :  [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 1 1 1 1 1 1 1 0 0 0 0 0]

Evaluating...

CHECKPOINT FILE :  C:\Users\vkhajuri.BLACKROCK\VirtualBox VMs\vmshared\NLP_DL\algo\cnn_sandbox_2\runs\1493840535\checkpoints\model-800
<generator object batch_iter at 0x000000020773A4C0>
NUMBER OF BATCHES :  1
[ 1.  0.  1.  1.  1.  1.  1.  0.  0.  1.  0.  0.  0.  1.  1.  1.  1.  0.
  1.  0.  1.  1.  0.  1.  1.  1.  0.  1.  1.  1.]
Total number of test examples: 30
Accuracy: 0.6
Saving evaluation to runs/1493840535/checkpoints/..\prediction.csv
This is the format of your plot grid:
[ (1,1) x1,y1 ]
[ (2,1) x1,y2 ]
'''